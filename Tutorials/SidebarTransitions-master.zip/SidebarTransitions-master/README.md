
Sidebar Transitions
=========
Some inspiration for transition effects for off-canvas navigations.

[article on Codrops](http://tympanus.net/codrops/?p=16292)

[demo](http://tympanus.net/Development/SidebarTransitions/)

[LICENSING & TERMS OF USE](http://tympanus.net/codrops/licensing/)